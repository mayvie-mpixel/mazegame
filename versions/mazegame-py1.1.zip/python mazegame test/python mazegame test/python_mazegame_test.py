# mazegame (pygame filemod test 1.1)
# 2025-09-09 12:14 mayvie pixel

import os

import pygame
# import math

# Initialize Pygame
pygame.init()
clock = pygame.time.Clock()
FPS = 20

# Set up the display
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("mazegame (py-0.1)")

# Initialize variables here

root = os.path.dirname(__file__)
print("root: " + root)  # parent directory

chunks = os.path.join(root, "chunks\\SC-0000000-0000000.bin")

print("chunks: " + chunks)

chunkdata = open(chunks, "rb")

bin = chunkdata.read()
print(bin)
# chunkdata.close()

blocksize = 30
blockgap = 2
blockinc = blockgap + blocksize
chunkscreensize = blockinc * 16 - blockgap
chunkoffsetx = (screen_width - chunkscreensize) >> 1
chunkoffsety = (screen_height - chunkscreensize) >> 1


# ...

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Game code here

    offset = 0x100

    for i in range(0x100):
        # print(bin[offset+i])
        if bin[offset + i] == 0x80:
            #draw square here
            pygame.draw.rect(screen, [200, 100, 100], (((i % 16) * blockinc) + chunkoffsetx, ((i >> 4) * blockinc) + chunkoffsety, blocksize, blocksize))

    # ...

    # Update the display
    pygame.display.flip()
    clock.tick(FPS)

# Quit Pygame
pygame.quit()























