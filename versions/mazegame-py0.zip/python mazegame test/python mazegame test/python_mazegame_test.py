# mazegame (pygame filemod test)
# 2024-09-20 21:38 mayvie pixel

import os

# data = b'\x48\x65\x6c\x6c\x6f\x20\x57\x6f\x72\x6c\x64\x21'  # binary data

# f = open('data', 'wb')

# bin = f.read()
# print(bin)

# f.close()

root = os.path.dirname(__file__)
print("root: " + root)  # parent directory

chunks = os.path.join(root, "chunks\\data.bin")

print("chunks: " + chunks)

chunkdata = open(chunks, "rb")

bin = chunkdata.read()
print(bin)
chunkdata.close()

